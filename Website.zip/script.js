document.getElementById('redeemForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevents the default form submission

    const codeInput = document.getElementById('codeInput').value.trim();
    const messageElement = document.getElementById('message');

    if (codeInput === '') {
        messageElement.textContent = 'Please enter a code.';
        messageElement.style.color = 'red';
    } else {
        // Replace this with your actual code validation logic
        const validCodes = ['CODE123', 'DISCOUNT50', 'WELCOME2024'];
        if (validCodes.includes(codeInput)) {
            messageElement.textContent = 'You have successfully redeemed your code!';
            messageElement.style.color = 'green';
        } else {
            messageElement.textContent = 'Invalid or expired code.';
            messageElement.style.color = 'red';
        }
    }
});